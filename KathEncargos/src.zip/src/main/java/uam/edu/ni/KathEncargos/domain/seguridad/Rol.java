package uam.edu.ni.KathEncargos.domain.seguridad;

public class Rol {
}
