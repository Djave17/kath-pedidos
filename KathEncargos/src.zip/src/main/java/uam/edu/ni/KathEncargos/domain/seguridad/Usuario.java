package uam.edu.ni.KathEncargos.domain.seguridad;

public class Usuario {
}
