package uam.edu.ni.KathEncargos.domain.pedidos;

public class HistorialEstadoPedido {
}
