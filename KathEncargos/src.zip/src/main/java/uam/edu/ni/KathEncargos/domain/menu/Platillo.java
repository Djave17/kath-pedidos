package uam.edu.ni.KathEncargos.domain.menu;

public class Platillo {


}
