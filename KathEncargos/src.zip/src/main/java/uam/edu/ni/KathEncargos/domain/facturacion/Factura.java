package uam.edu.ni.KathEncargos.domain.facturacion;

public class Factura {
}
